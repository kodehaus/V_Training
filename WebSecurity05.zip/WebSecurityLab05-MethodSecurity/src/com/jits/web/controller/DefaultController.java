package com.jits.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.jits.data.Office;
import com.jits.data.OfficeDao;
import com.jits.data.UserDao;

@Controller
@RequestMapping("/")
public class DefaultController {
	@Autowired
	private OfficeDao officeDao;
	
	@Autowired
	private UserDao userDao;

	@RequestMapping
	public ModelAndView navigateHome(ModelAndView modelAndView) {
		modelAndView.setViewName("index");
		return modelAndView;
	}
	
	@Secured(value="ROLE_USER")
	@RequestMapping("/user")
	public ModelAndView viewUsers(ModelAndView modelAndView, @ModelAttribute Command cmd) {
		modelAndView.setViewName("user");
		modelAndView.addObject("userList", userDao.findAll());
		return modelAndView;
	}

	@RequestMapping(value="/search", method=RequestMethod.POST)
	public ModelAndView searchUsers(ModelAndView modelAndView, @ModelAttribute("command") Command cmd) {
		modelAndView.setViewName("user");
		modelAndView.addObject("userList", userDao.findByOffice(cmd.getOfficeId()));
		return modelAndView;
	}


@ModelAttribute("offices")
	public List<Office> getOffices(){
	List<Office> oList = officeDao.findAll();
		return oList;
	}


}
