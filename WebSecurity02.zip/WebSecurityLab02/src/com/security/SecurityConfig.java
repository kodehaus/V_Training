package com.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{

	@Override
	public void configure (HttpSecurity http) throws Exception {
		http.csrf().disable();
//		http.authorizeRequests().antMatchers("/admin/**").access("hasRole('ROLE_ADMIN')").and().httpBasic();
//		http.authorizeRequests().antMatchers("/*").access("hasRole('ROLE_ADMIN')").and().httpBasic();
		http.authorizeRequests().antMatchers("/admin/**").hasAnyRole("ADMIN").and().httpBasic();
		http.authorizeRequests().antMatchers("/user/**").hasRole("USER").and().httpBasic();
		http.authorizeRequests().antMatchers("/*").hasAnyRole("USER","ADMIN").and().httpBasic();
	}
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception{
		auth.inMemoryAuthentication().withUser("cat").password("abc").roles("USER");
		auth.inMemoryAuthentication().withUser("dog").password("efg").roles("ADMIN");
	}
}
