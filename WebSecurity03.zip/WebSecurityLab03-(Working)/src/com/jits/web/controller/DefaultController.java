package com.jits.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class DefaultController {

	@RequestMapping
	public ModelAndView navigateHome(ModelAndView modelAndView) {
		modelAndView.setViewName("index");
		return modelAndView;
	}

	@RequestMapping("/user")
	public ModelAndView navigateUser(ModelAndView modelAndView) {
		modelAndView.setViewName("user");
		return modelAndView;
	}
}
