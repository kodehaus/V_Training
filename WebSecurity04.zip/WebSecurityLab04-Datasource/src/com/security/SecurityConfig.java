package com.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	@Autowired
	private DataSource dataSource;

	@Override
	public void configure (HttpSecurity http) throws Exception {
		http.csrf().disable();
//		http.authorizeRequests().antMatchers("/admin/**").access("hasRole('ROLE_ADMIN')").and().httpBasic();
//		http.authorizeRequests().antMatchers("/*").access("hasRole('ROLE_ADMIN')").and().httpBasic();
		http.authorizeRequests().antMatchers("/admin/**").hasAnyRole("ADMIN")
		.antMatchers("/user/**").hasRole("USER")
		.antMatchers("/*").hasAnyRole("USER","ADMIN").and()
		.formLogin()
		.loginPage("/login").permitAll().and()
		.logout().permitAll();
	}
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception{
//		auth.inMemoryAuthentication().withUser("cat").password("abc").roles("USER");
//		auth.inMemoryAuthentication().withUser("dog").password("efg").roles("ADMIN");

	
		auth.jdbcAuthentication().dataSource(dataSource)
		.usersByUsernameQuery("select username, password, enabled from users where username=?")
		.authoritiesByUsernameQuery("select username, authority from authorities where username=?");
	
	}
    
    @Bean(name = "dataSource")
    public DataSource dataSource() {
		System.out.println("datasource lookingg loaded/r/r/r/r/r");
    		SimpleDriverDataSource ds = new SimpleDriverDataSource();
    		ds.setDriverClass(org.h2.Driver.class);
    		ds.setUrl("jdbc:h2:tcp://localhost/~/test");
    		ds.setUsername("GUEST");
    		ds.setPassword("abc");
    		System.out.println("datasource loaded");
    		return ds;
    }

}
