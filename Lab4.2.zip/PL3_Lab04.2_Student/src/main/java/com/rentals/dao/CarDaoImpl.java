package com.rentals.dao;

import java.util.ArrayList;

import java.util.Collection;

import com.rentals.core.RentalCar;

public class CarDaoImpl implements RentalService  {
	
	private Inventory inventory;

	public CarDaoImpl(Inventory inventory) {
		setInventory(inventory);
	}
	
	@Override
	public Collection<RentalCar> getCarsPerLocationAndPrice(String location, double price) {
		Collection<RentalCar> selectedCars = new ArrayList<RentalCar>();
		Collection<RentalCar> inventoryCars = inventory.getInventory().values();
		for (RentalCar rentalCar : inventoryCars) {
			if((rentalCar.getLocation().equals(location) || location.equals("")) && rentalCar.getDailyRate() <= price){
				selectedCars.add(rentalCar);
			}
		}
		return selectedCars;
	}

	@Override
	public Collection<RentalCar> getAll() {
	 	return inventory.getInventory().values();
	}

	private void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	
	public RentalCar getCarById(long id){
		RentalCar returnCar = null;
		for (RentalCar car : getAll()) {
			if(car.getId() == id){
				returnCar = car;
			}
		}
		return returnCar;
	}
	
	

}
