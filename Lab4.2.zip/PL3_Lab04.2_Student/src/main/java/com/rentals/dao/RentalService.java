package com.rentals.dao;

import java.util.Collection;

import com.rentals.core.RentalCar;

public interface RentalService {

	public Collection<RentalCar> getCarsPerLocationAndPrice(String location, double price);

	public Collection<RentalCar> getAll();
	
	public RentalCar getCarById(long id);
	
}
