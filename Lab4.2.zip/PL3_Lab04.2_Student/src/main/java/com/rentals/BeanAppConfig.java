package com.rentals;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.rentals.dao.CarDaoImpl;
import com.rentals.dao.Inventory;
import com.rentals.dao.RentalService;
import com.rentals.service.CarServiceImpl;

@Configuration
@Import(InventoryAppConfig.class)
@PropertySource(value = "classpath:rental.properties")
public class BeanAppConfig {
	@Autowired
	Inventory inventory;
	
	@Value("${carService.Min}" )
	int minValue;

	@Value("${carService.Max}" )
	int maxValue;

	@Bean(name = "rentalService")
	public RentalService getRentalService() {
		CarDaoImpl rental = new CarDaoImpl(inventory);
		return rental;
	}

	@Bean(name="carSvcImpl01")
	public CarServiceImpl getCarServiceImplementation(){
		return new CarServiceImpl(getRentalService(), minValue, maxValue);
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
