package com.rentals.service;

import java.util.ArrayList;
import java.util.Collection;

import com.rentals.core.RentalCar;
import com.rentals.dao.RentalService;


public class CarServiceImpl implements CarService{
	
	private RentalService dao;
	private int min;
	private int max;
	
	
	public CarServiceImpl(){
		
	}
	
	public CarServiceImpl(RentalService dao, int min, int max){
		setDao(dao);
		setMin(min);
		setMax(max);				
	}

	
	@Override
	public RentalService getDao() {
		return dao;
	}
	
	private void setDao(RentalService dao){
		this.dao = dao;
	}
	@Override
	public Collection<RentalCar> getCarsPerLocationAndPrice(String location, double price) {
		Collection<RentalCar> cars =  dao.getCarsPerLocationAndPrice(location, price);
		return limitReturn(cars);
	}
	
	@Override
	public Collection<RentalCar> getAll() {
		return limitReturn(dao.getAll());
	}
	
	private Collection<RentalCar> limitReturn(Collection<RentalCar> inventory){
		Collection<RentalCar> map = new ArrayList<RentalCar>();
		int i = 1;
		if((getMin() > 0) && (getMax() > 0)){
			for (RentalCar rentalCar : inventory) {
				if((i >= getMin()) && (i <= getMax())){
					map.add(rentalCar);
				}
				i+=1;
			}
		} else {
			map = inventory;
		}
		return map;
	}
	public RentalCar getCarById(long id){
		return dao.getCarById(id);
	}
	
	private void setMin(int min) {
		this.min = min;
	}
	private void setMax(int max) {
		this.max = max;
	}
	private int getMin() {
		return min;
	}
	private int getMax() {
		return max;
	}
}
