package com.rentals.service;

import java.util.Collection;

import com.rentals.core.RentalCar;
import com.rentals.dao.RentalService;

public interface CarService extends RentalService{
	public RentalService getDao();
	Collection<RentalCar> getCarsPerLocationAndPrice(String location, double price);
	Collection<RentalCar> getAll();


}
