package com.rentals.converter;

import java.beans.PropertyEditorSupport;

import com.rentals.core.RentalCar;

public class RentalCarPropertyEditor extends PropertyEditorSupport {

	@Override
	public void setAsText(String arg0) throws IllegalArgumentException {
		String[] values = null;
		RentalCar car = null;
		try{
			values = arg0.split("\\|");
			car = new RentalCar(Long.parseLong(values[0]), values[1], values[2], Double.parseDouble(values[3]),
					values[4], values[5]);
		} catch(Exception e){
			throw new IllegalArgumentException("Unable to create rental car object due to invalid string values: " + arg0);
		}
		setValue(car);
	}

}
