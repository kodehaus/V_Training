package com.rentals;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.rentals.converter.RentalCarConverter;
import com.rentals.core.RentalCar;
import com.rentals.dao.Inventory;

@Configuration
public class InventoryAppConfig {
	@Bean(name="inventory")
	public Inventory getInventory(){
		Inventory inventory = new Inventory();
		inventory.setCar(getCar());
		return inventory;
	}
	
	@Bean(name="newCar")
	public RentalCar getCar(){
		RentalCarConverter conv = new RentalCarConverter();
		return conv.convert("99|DAL|Compact|18.50|Toyota|Corolla");
	}

}
