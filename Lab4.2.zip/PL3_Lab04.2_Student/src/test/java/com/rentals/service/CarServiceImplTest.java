package com.rentals.service;

import static org.junit.Assert.*;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.hamcrest.CoreMatchers.*;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.rentals.BeanAppConfig;
import com.rentals.InventoryAppConfig;
import com.rentals.dao.RentalService;
import com.rentals.service.CarService;
import com.rentals.service.CarServiceImpl;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={InventoryAppConfig.class,BeanAppConfig.class})
public class CarServiceImplTest {
	
	@Inject
	private CarServiceImpl carSvcImpl;

	@Test
	public void testCarServiceImplIsNotNull() {
		
		assertThat(carSvcImpl, is(notNullValue()));
		assertThat(carSvcImpl.getDao(),is(instanceOf(RentalService.class)));
	}

	@Test
	public void testCarServiceImplHasProperValues() {
		assertThat(carSvcImpl.getDao(),is(instanceOf(RentalService.class)));
		assertThat(carSvcImpl,is(instanceOf(CarService.class)));
	}

}
