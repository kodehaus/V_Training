package com.rentals.dao;

import static org.junit.Assert.*;


import javax.inject.Inject;

import org.junit.Before;

import static org.hamcrest.CoreMatchers.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.rentals.BeanAppConfig;
import com.rentals.InventoryAppConfig;
import com.rentals.dao.CarDaoImpl;
import com.rentals.service.CarServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={InventoryAppConfig.class,BeanAppConfig.class})
public class CarDaoImplTest {
	
	@Inject
	CarServiceImpl carSvc;
	
	@Inject
	private CarDaoImpl carDaoImpl;
	
	@Before
	public void startUp(){
	}

	@Test
	public void testClassPathXMLCarDaoWithClassIdentifierById() {
		assertThat(carDaoImpl, is(notNullValue()));
	}

	@Test
	public void testClassPathXMLCarDaoWithNoClassIdentifierById() {
		assertThat(carDaoImpl, is(notNullValue()));
	}

	@Test
	public void testClassPathXMLCarDaoWithNoClassIdentifierByName() {
		assertThat(carDaoImpl, is(notNullValue()));
	}

	@Test
	public void testClassPathXMLCarDaoWithClassIdentifierByName() {
		assertThat(carDaoImpl, is(notNullValue()));
	}

	@Test
	public void testReturnValue(){
		assertThat(carSvc.getAll().size(), is(5));
	}

	@Test
	public void testReturnInjectedCarById(){
		assertThat(carSvc.getCarById(99), is(notNullValue()));
	}

	@Test
	public void testReturnValueOCarsByLocation(){
		assertThat(carSvc.getCarsPerLocationAndPrice("PEA", 36.00).size(), is(2));
		assertThat(carSvc.getCarsPerLocationAndPrice("PEA", 32.00).size(), is(1));
		assertThat(carSvc.getCarsPerLocationAndPrice("PEA", 25.00).size(), is(0));
		assertThat(carSvc.getCarsPerLocationAndPrice("", 36.00).size(), is(5));
	}

}
