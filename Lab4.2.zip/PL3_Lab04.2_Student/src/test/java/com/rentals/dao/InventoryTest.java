package com.rentals.dao;

import static org.junit.Assert.*;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.hamcrest.CoreMatchers.*;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.rentals.InventoryAppConfig;
import com.rentals.core.RentalCar;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={InventoryAppConfig.class})
public class InventoryTest {

	@Inject
	private Inventory inventory;
	

	@Test
	public void testInventoryNotNull() {
		assertThat(inventory, is(notNullValue()));
	}	
	
	@Test
	public void testInventoryCount() {
		assertThat(inventory.getInventory().size(), is(16));
	}
	
	@Test
	public void testRentalCarObject(){
		Object[] keys = new Long[inventory.getInventory().size()];
		keys = inventory.getInventory().keySet().toArray();
		long id = (Long) keys[0];
		RentalCar car = inventory.getInventory().get(id);
		assertThat(car, is(notNullValue()));
		assertThat(car.getId(), is(id));
	}

	@Test
	public void testInventoryCompactSpElCount() {
		assertThat(inventory.getCompacts().size(), is(4));
	}
	
	@Test
	public void testDailyRateGreaterThanThirtyNine() {
		assertThat(inventory.getExclusive().size(), is(2));
	}
	
}
