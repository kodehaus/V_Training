package com.jits.client;

import static org.junit.Assert.*;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;


	
public class UserRequestorTest {
	private UserRequestor request = new UserRequestor();

	@Before
	public void setUp(){
		request = new UserRequestor();
		request.setTemplate(new RestTemplate());
	}

	@Test
	public void test() {
//		System.out.println(request.getByUserName("sing"));
		System.out.println(request.getObjectByUserName("sing"));
		
	}

}
