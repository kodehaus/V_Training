package com.jits.client;

import org.springframework.web.client.RestTemplate;

import com.jits.data.User;


public class UserRequestor {
	private RestTemplate template;


	public void setTemplate(RestTemplate template) {
		this.template = template;
	}


	public String getByUserName(String username){
		String url = "http://localhost:8080/RESTServices02/user/{username}";
		System.out.println("printing url:" + url);
		return template.getForObject(url,String.class,username); 
	}
	

	public User getObjectByUserName(String username){
		String url = "http://localhost:8080/RESTServices02/user/obj/{username}";
		return template.getForObject(url,User.class,username); 
	}
	
}
