package com.rentals.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.rentals.core.RentalCar;

public class CarDaoImpl implements RentalService  {
	
	private Inventory inventory;

	@Override
	public Collection<RentalCar> getCarsPerLocationAndPrice(String location, double price) {
		Collection<RentalCar> selectedCars = new ArrayList<RentalCar>();
		Collection<RentalCar> inventoryCars = inventory.getInventory().values();
		for (RentalCar rentalCar : inventoryCars) {
			if((rentalCar.getLocation().equals(location) || location.equals("")) && rentalCar.getDailyRate() <= price){
				selectedCars.add(rentalCar);
			}
		}
		return selectedCars;
	}

	@Override
	public Collection<RentalCar> getAll() {
	 	return inventory.getInventory().values();
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	
	

}
