package com.rentals.dao;

import java.util.ArrayList;
import java.util.Collection;

import javax.inject.Inject;


import com.rentals.core.RentalCar;

public class CarDaoImpl implements CarDao  {
	
	private Inventory inventory;
    @Inject
	public CarDaoImpl(Inventory inventory) {
 		this.inventory = inventory;
	}

	@Override
	public Collection<RentalCar> getCarsPerLocationAndPrice(String location, double price) {
		Collection<RentalCar> selectedCars = new ArrayList<RentalCar>();
		Collection<RentalCar> inventoryCars = inventory.getInventory().values();
		for (RentalCar rentalCar : inventoryCars) {
			if(rentalCar.getLocation().equals(location) && rentalCar.getDailyRate() <= price){
				selectedCars.add(rentalCar);
			}
		}
		return selectedCars;
	}

	@Override
	public Collection<RentalCar> getAll() {
	 	return inventory.getInventory().values();
	}

	 
	

}
