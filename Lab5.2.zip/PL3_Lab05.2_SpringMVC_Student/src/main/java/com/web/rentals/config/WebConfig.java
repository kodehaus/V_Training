package com.web.rentals.config;

public class WebConfig {

}
