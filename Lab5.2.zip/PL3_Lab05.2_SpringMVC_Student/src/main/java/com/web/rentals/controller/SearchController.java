package com.web.rentals.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.rentals.core.RentalCar;
import com.rentals.service.CarService;

@Controller
@RequestMapping("/rental")
public class SearchController {
	
	@Autowired
	private CarService carService;

	@RequestMapping(method = RequestMethod.GET)
	public String search() {
		return "search";
	}

	@RequestMapping(value = "/location", method = RequestMethod.POST)
	public ModelAndView getCars(@RequestParam("pickUp") String pickUp, @RequestParam("price") double price) {
		Collection<RentalCar> cars = carService.getCarsPerLocationAndPrice(pickUp, price);
		return new ModelAndView("search", "cars", cars);
//		return "/WEB-INF/views/search.jsp";
	}

}
