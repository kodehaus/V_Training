package com.rentals.dao;

public class CarDaoImpl implements RentalService{
	public String getConnection(){
		return "Connection Made";
	}
}
