package com.rentals.dao;

public interface RentalService {
	public String getConnection();
}
