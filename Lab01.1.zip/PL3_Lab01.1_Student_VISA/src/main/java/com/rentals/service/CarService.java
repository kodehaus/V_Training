package com.rentals.service;

import com.rentals.dao.RentalService;

public interface CarService extends RentalService{
	public RentalService getDao();
}
