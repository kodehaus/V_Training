package com.rentals.service;

import com.rentals.dao.CarDaoImpl;
import com.rentals.dao.RentalService;

public class CarServiceImpl implements CarService{
	private CarDaoImpl dao;
	
	@Override
	public RentalService getDao() {
		return dao;
	}
	public void setDao(CarDaoImpl dao){
		this.dao = dao;
	}
	
	@Override
	public String getConnection() {
		return dao.getConnection();
	}

}
