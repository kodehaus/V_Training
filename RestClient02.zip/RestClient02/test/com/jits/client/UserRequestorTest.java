package com.jits.client;

import static org.junit.Assert.*;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.jits.data.User;


	
public class UserRequestorTest {
	private UserRequestor request = new UserRequestor();

	@Before
	public void setUp(){
		request = new UserRequestor();
		request.setTemplate(new RestTemplate());
	}

	@Test
	public void test() {
//		System.out.println(request.getByUserName("sing"));
		System.out.println(request.getObjectByUserName("sing"));
		
	}
	
	@Test
	public void testAddUser(){
		User me = new User();
		me.setEnabled(true);
		me.setFirstName("mumr");
		me.setLastName("Roson");
		me.setUserName("oennu");
		me.setPassword("obiro");
		me.setOfficeId(2);
		System.out.println(request.addUser(me));
		
	}
	@Test
	public void testJaxbUser(){
		User carrie = request.getByUserNameAXB("sing");
		System.out.println(carrie);
		
	}

}
