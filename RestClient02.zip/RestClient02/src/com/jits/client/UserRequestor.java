package com.jits.client;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.jits.UserConfirmation;
import com.jits.data.User;


public class UserRequestor {
	private RestTemplate template;


	public void setTemplate(RestTemplate template) {
		this.template = template;
	}


	public String getByUserName(String username){
		String url = "http://localhost:8080/RESTServices03/user/{username}";
		System.out.println("printing url:" + url);
		return template.getForObject(url,String.class,username); 
	}
	

	public User getObjectByUserName(String username){
		String url = "http://localhost:8080/RESTServices03/user/obj/{username}";
		return template.getForObject(url,User.class,username); 
	}
	
	public UserConfirmation addUser(User user){
		String url = "http://localhost:8080/RESTServices03/user/add";
		HttpEntity<User> userEnt = new HttpEntity<User>(user);
		ResponseEntity<UserConfirmation> resp = template.postForEntity(url, userEnt, UserConfirmation.class);
		return resp.getBody();
	}
	
	public User getByUserNameAXB(String username){
		String url = "http://localhost:8080/RESTServices03/user/jax/{username}";
		return template.getForObject(url, User.class, username);		
	}

}
