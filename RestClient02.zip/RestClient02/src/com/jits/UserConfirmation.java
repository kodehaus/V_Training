package com.jits;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserConfirmation {

	private String message;
	private String date;
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserConfirmation [message=" + message + ", date=" + date + "]";
	}
	
	
	
}
