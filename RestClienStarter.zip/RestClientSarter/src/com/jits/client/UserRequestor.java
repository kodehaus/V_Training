package com.jits.client;


public class UserRequestor {
	
}