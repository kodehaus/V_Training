package com.jits.data;

public class User {
	
	
	@Override
	public String toString() {
		return "something";
	}
	
	
	

}
