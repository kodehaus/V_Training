package com.jits;


public class UserConfirmation {

	
	
}
