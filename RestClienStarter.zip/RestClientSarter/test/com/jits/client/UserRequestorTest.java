package com.jits.client;

	
public class UserRequestorTest {

}
