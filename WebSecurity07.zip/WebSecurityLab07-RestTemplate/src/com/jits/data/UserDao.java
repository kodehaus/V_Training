package com.jits.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;  
	
/*	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	} */ 
	
	public int saveUser(User user){
		String query = "insert into users values(:firstName, :lastName, :officeId, :username, :password, :enabled)";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("firstName", user.getFirstName());
		params.put("lastName", user.getLastName());
		params.put("officeId", user.getOfficeId());
		params.put("username", user.getUserName());
		params.put("password", user.getPassword());
		params.put("enabled", user.isEnabled());
		return this.jdbcTemplate.update(query, params);
	}
	
	public User getUserByFirstName(String firstName){
		String query = "select firstName, lastName, officeId, userName, password, enabled from users where firstName = ?";
		return this.jdbcTemplate.queryForObject(query, new Object[]{firstName}, new BeanPropertyRowMapper<User>(User.class));
		
	}
	public User getUserByUserName(String userName){
		String query = "select firstName, lastName, officeId, userName, password, enabled from users where username = ?";
		return this.jdbcTemplate.queryForObject(query, new Object[]{userName}, new BeanPropertyRowMapper<User>(User.class));
	}

	public List<User> findAll() {
		List<User> locatedUsers = new ArrayList<User>();
		String query = "select firstName, lastName, officeId, userName, enabled from users";
		SqlRowSet srs = jdbcTemplate.queryForRowSet(query);
		while(srs.next()){
			User currentUser = new User();
			currentUser.setFirstName((String) srs.getString(1));
			currentUser.setLastName((String) srs.getString(2));
			currentUser.setOfficeId((int) srs.getInt(3));
			currentUser.setUserName((String) srs.getString(4));
			currentUser.setEnabled((boolean) srs.getBoolean(5)); 
			locatedUsers.add(currentUser);
		}
		return locatedUsers;
	}

	public List<User> findByOffice(int id) {
		List<User> locatedUsers = new ArrayList<User>();
		String query = "select firstName, lastName, officeId, userName, enabled from users where officeId = ?";
		SqlRowSet srs = jdbcTemplate.queryForRowSet(query, new Object[]{id});
		while(srs.next()){
			User currentUser = new User();
			currentUser.setFirstName((String) srs.getString(1));
			currentUser.setLastName((String) srs.getString(2));
			currentUser.setOfficeId((int) srs.getInt(3));
			currentUser.setUserName((String) srs.getString(4));
			currentUser.setEnabled((boolean) srs.getBoolean(5)); 
			locatedUsers.add(currentUser);
		}
		return locatedUsers;
	}
}
