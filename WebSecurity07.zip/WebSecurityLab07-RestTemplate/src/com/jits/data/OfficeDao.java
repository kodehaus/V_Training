package com.jits.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class OfficeDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;  
	
	
	public int saveOffice(Office office){
		String query = "insert into offices values(:id, :code)";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", office.getOfficeId());
		params.put("code", office.getCode());
		return this.jdbcTemplate.update(query, params);
	}
	
	public Office getOffice(int id){
		String query = "select * from offices where id = ?)";
		Office office = (Office) jdbcTemplate.queryForObject(query, new Object[]{id}, new BeanPropertyRowMapper<Office>(Office.class));
		return office;
	}

	public List<Office> findAll(){
		String query = "select * from offices";
		List<Office> offices  = jdbcTemplate.query(query, new BeanPropertyRowMapper<Office>(Office.class));
		return offices;
	}
	
}
