package com.jits.web.controller;

 
 
public class Command {
	private int officeId;

	/**
	 * @return the officeId
	 */
	public int getOfficeId() {
		return officeId;
	}

	/**
	 * @param officeId the officeId to set
	 */
	public void setOfficeId(int officeId) {
		this.officeId = officeId;
	}
	 
	

}
