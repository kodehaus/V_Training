create table users(
	firstName varchar(50) not null,
	lastName varchar (50) not null,
	username varchar_ignorecase(50) not null primary key,
	password varchar_ignorecase(50) not null, 
	enabled boolean not null);

create table authorities(
	username varchar_ignorecase(50) not null,
	authority varchar_ignorecase(50) not null,
	constraint fk_authorities_users foreign key(username) references users(username));
    
create unique index ix_auth_username on authorities (username,authority);
      
insert into users values('Mel','Loewe','chill', 'out',true);
insert into users values('Carrier','Oakie','sing','song',true);
insert into users values('Holly','Wood','big','dreams',true);

insert into authorities values('chill','ROLE_USER');
insert into authorities values('sing','ROLE_USER');
insert into authorities values('sing','ROLE_ADMIN');
insert into authorities values('big','ROLE_ADMIN');

CREATE USER GUEST PASSWORD 'abc';

GRANT ALL ON USERS TO GUEST;
GRANT ALL ON AUTHORITIES TO GUEST;