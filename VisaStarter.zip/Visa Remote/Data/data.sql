create table users(
	firstName varchar(50) not null,
	lastName varchar (50) not null,
        officeId int not null,
	username varchar_ignorecase(50) not null primary key,
	password varchar_ignorecase(50) not null, 
	enabled boolean not null);

create table offices(
        officeId int primary key not null,
        code varchar(50) not null);

create table authorities(
	username varchar_ignorecase(50) not null,
	authority varchar_ignorecase(50) not null,
	constraint fk_authorities_users foreign key(username) references users(username));
create unique index ix_auth_username on authorities (username,authority);
      
insert into offices values(1,'ATL');
insert into offices values(2,'DEN');
insert into offices values(3,'CHI');
insert into offices values(4,'LOS');

insert into users values('Mel','Loewe',1,'chill', 'out',true);
insert into users values('Carrie','Oakie',2,'sing','song',true);
insert into users values('Holly','Wood',4,'big','dreams',true);

insert into authorities values('chill','ROLE_USER');
insert into authorities values('sing','ROLE_USER');
insert into authorities values('sing','ROLE_ADMIN');
insert into authorities values('big','ROLE_ADMIN');

CREATE USER GUEST PASSWORD 'abc';

GRANT ALL ON USERS TO GUEST;
GRANT ALL ON AUTHORITIES TO GUEST;
GRANT ALL ON OFFICES TO GUEST;