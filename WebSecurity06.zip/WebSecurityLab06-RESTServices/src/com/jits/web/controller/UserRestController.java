package com.jits.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jits.data.UserDao;

@RestController
public class UserRestController {
	@Autowired
	UserDao userDao;

	@RequestMapping(value="/user/{username}", method=RequestMethod.GET)
	public @ResponseBody String getByUserName(@PathVariable("username") String username){
		return userDao.getUserByUserName(username).toString();
	}

	@RequestMapping(value="/user/*/any", method=RequestMethod.GET)	
	public String getByRequestId(@RequestParam(value = "firstName", required = false, defaultValue = "Mel") String firstName){
		//@RequestParam(value = "id", required = false, defaultValue = "4)
		return userDao.getUserByFirstName(firstName).toString();
	}

}
